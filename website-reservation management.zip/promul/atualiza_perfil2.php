<!doctype html>
<?php
session_start();
if ($_SESSION['acesso_valido'] != 1)
  header('Location: login.php');
?>
<html>
<head>
  <meta charset="utf-8">
  <title>Administração</title>
<link rel="icon" type="image/png" href="imagens/cenas-03.png">
  <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>
 
<body>  

  <nav class="navbar navbar-inverse navbar-fixed-top">

      <div class="container-fluid">

        <div class="navbar-header">

          <a class="navbar-brand" href="index.php" target="_blank">Casa S.Bento</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="perfil.php">Perfil</a></li>
            <li><a href="ajuda.php">Ajuda</a></li>
            <li><a href="logout.php">Sair</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid">

      <div class="row">

        <div class="col-sm-3 col-md-2 sidebar">

          <ul class="nav nav-sidebar">

            <li class="active"><a>Reservas<span class="sr-only">(current)</span></a></li>
            <li ><a href="listar_reserva.php">Reservas Pendentes</a></li>
            <li><a href="reserva_aceite.php">Reservas Aceites</a></li>
            <li><a href="reserva_rejeitada.php">Reservas Rejeitadas</a></li>
          </ul>
          <ul class="nav nav-sidebar" >
            <li class="active"><a>Preços</a></li>
            <li><a href="atualizar_preco.php">Atualizar Preço</a></li>
            <li><a >Promoção<h6>*(em construção)*</h6></a></li>
          </ul>
          <!--<ul class="nav nav-sidebar">
            <li class="active"><a>Fotografias</a></li>
            <li><a href="">Inserir Fotografias</a></li>
            <li><a href="">Atualizar Descrição</a></li>
            <li><a href="">Apagar Fotografias</a></li>  
          </ul>-->
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Atualizar Reservas</h1>

          <div class="row placeholders">

            
          </div>

         <?php

	// Tratamento dos dados recebidos por POST
	$nome        = $_POST['nome'];
	$telemovel	 = $_POST['telemovel'];
	$email		 = $_POST['email'];

	// ---------------------------------------------------------------------
	// MANIPULAÇÃO DA BASE DE DADOS
	// ---------------------------------------------------------------------

	// Passo 1
	// Estabelecer ligação (conexão) com a base de dados
	// ---------------------------------------------------------------------
	$servidorBD   = 'localhost';
	$utilizadorBD = 'root';
	$passwordBD   = '';
	$nomeBD       = 'website';
	$ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

	// Passo 2
	// Testar a conexão
	// ---------------------------------------------------------------------
	if(mysqli_connect_errno()){
		die('Não foi possível a ligação à base de dados.'
		. mysqli_connect_error() . ':' 
		. mysqli_connect_errno());
	}

	// Passo 3
	// Definir a query SQL
	// ---------------------------------------------------------------------
	
	// INSERIR
	// $query1 = "INSERT INTO contactos (nome,contacto) VALUES ('".$nome."', '".$contacto."')";

	// ATUALIZAR
	
	$query1 = "UPDATE perfil SET nome='".$nome."', email='".$email."', telemovel='".$telemovel."' ";
	
	// CONSULTAR
	// $query1 = "SELECT * FROM contactos";

	// Passo 4
	// Executar a query e guardar resposta numa variável
	$resultado = mysqli_query($ligacao, $query1);

	// Passo 5
	// Verificar o sucesso da execução da query 
	// ---------------------------------------------------------------------
	if(!$resultado) {
		die('Problemas encontrados na execução da query.');
	} else {
		// Passo 6
		// A execução da query teve sucesso
		// Informar utilizador do sucesso da inserção
		// ---------------------------------------------------------------------
		echo "<div class=\"mensagens sucesso\">Perfil alterado com sucesso! </div>";
		echo "<nav>";
    echo "<ul class=\"pager\">";
    echo "<li><a href=\"perfil.php\">Voltar</a></li>";
    echo "</ul>";
    echo "</nav>";

		// Passo 7
		// Libertar os dados devolvidos pela Base de Dados
		// ---------------------------------------------------------------------
		// mysqli_free_result($resultado);
	}

	// Passo 8
	// Fechar a ligação à Base de Dados
	// ---------------------------------------------------------------------
	mysqli_close($ligacao);
	?>
      
          
        </div>
      </div>
    </div>

  <script src="js/jquery-2.1.3.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>



