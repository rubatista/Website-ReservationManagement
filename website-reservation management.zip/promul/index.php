<html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Home</title>
	
	<link rel="stylesheet" href="css/style.css" type="text/css" />
	
	<link rel="icon" type="image/png" href="imagens/fav.jpg">
	<script src="jquery/jquery-2.1.3.min.js"></script>
    <script src="jquery-ui-1.11.3/jquery-ui.js"></script>
	
</head>
<script>


</script>

		
		<!-- inicio header -->
	<section class="imagem">
		<header>
			<div class="menu">
				<img src="imagens/logo-02.png" class="logo" alt="" titl=""/></a>
				<nav>
					<ul>
						<li><a href="#" class="botao_login">Home</a></li>
						<li><a href="#casa" class="botao_login">Informações</a></li>
						<li><a href="#sobre" class="botao_login">Sobre</a></li>
						<li><a href="#reserva" class="botao_login">Reservar</a></li>
						<li><a href="#footer" class="botao_login">Contacto</a></li>
					</ul>
					
				</nav>
			</div>
		</header>

		<!--  fim do header  -->

			<section class="caption">
				<h2 class="caption">As Férias de Sonho</h2>
				<h3 class="properties">Paisagem - Sossego - Tranquilidade</h3>
			</section>
	</section>

	<!--inicio barra -->
	<section class="barra_informacoes">
		<div id="casa" class="wrapper_informacoes">
			<h3>Informações</h3>
		</div>
	</section>
	<!--  Fim da barra  -->

	<!-- imagens casa -->
	<section class="lista">

		<div class="wrapper">
			<ul class="propriedades_lista">
				<li>
					<a>
						<img src="imagens/image1.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Cama de rede.</h2>
					</div>
				</li>
				<li>
					<a>
						<img src="imagens/image2.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Vista da sala para o exterior.</h2>
					</div>
				</li>
				<li>
					<a>
						<img src="imagens/image3.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Exterior da casa/jardim.</h2>
					</div>
				</li>
				<li>
					<a>
						<img src="imagens/image4.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Quarto de casal.</h2>
					</div>
				</li>
				<li>
					<a>
						<img src="imagens/image5.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Quartos de solterios/2 camas.</h2>
					</div>
				</li>
				<li>
					<a >
						<img src="imagens/image6.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Exterior da casa.</h2>
					</div>
				</li>
				<li>
					<a >
						<img src="imagens/image7.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Espaço para relaxar.</h2>
					</div>
				</li>
				<li>
					<a >
						<img src="imagens/image8.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Interior da casa/Sala de estar.</h2>
					</div>
				</li>
				<li>
					<a >
						<img src="imagens/image10.png" alt="" title="" class="propriedade_img"/>
					</a>
					
					<div class="descricao_casa">
						
						<h2>Sala de estar com lareira.</h2>
					</div>
				</li>

			</ul>

			<div class="preco">

	<?php
	$servidorBD   = 'localhost';
	$utilizadorBD = 'root';
	$passwordBD   = '';
	$nomeBD       = 'website';
	$ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);


	if(mysqli_connect_errno()){
		die('Não foi possível a ligação à base de dados.'
		. mysqli_connect_error() . ':' 
		. mysqli_connect_errno());
	}

	
	$query1 = "SELECT preco FROM preco WHERE id_preco=1";


	$resultado = mysqli_query($ligacao, $query1);

	if(!$resultado) {
		die('Problemas encontrados na execução da query.');
	} else {


		while($res = mysqli_fetch_assoc($resultado)) {
			$preco	 =  $res['preco'];	
		}


		mysqli_free_result($resultado);
	}

	mysqli_close($ligacao);
	?>
				<a class="preco_btn"><?php echo $preco  ?>€/noite</a>
			</div>
			</div>
		</section>

		<section class="barra_sobre">
				<div id="sobre" class="wrapper_sobre">
					<h3>Sobre</h3>
				</div>
		</section>

		<section class="sobre_texto">
			<div class="texto_sobre" >
			<p><em>A casa de S. Bento fica situada na margem direita do Rio Caldo, na freguesia da Caniçada, com uma vista esplêndida sobre a Albufeira da Caniçada.</p>
			 
			<p>A "um pequeno passo" da Vila de Viera do Minho, das pontes de Rio Caldo e da Vila do Gerês , esta casa tem uma localização 
			estratégica para proporcionar aos seus hóspedes uma estadia cómoda e aprazível, própria dos ambientes rurais e bucólicos.</p>
			 
			<p>Dispoõe de um belo jardim sobranceiro ao Rio, convidativo nas tardes e noites de Verão.</p>
			 
			<p>A casa tem capacidade para albergar 6 pessoas, dispondo de dois quartos e uma sala com sofá-cama.</p>
			 
			<p>Para os dias de frio e inverno, possui uma sala de estar e jantar com uma lareira convidativa ao aconchego do lar.</p>
			 
			<p><p>Para os dias e noites de Verão, poderá sempre disfrutar de uma sala de verão, existente no exterior da casa com cozinha anexa, propicia a 
			convívios, jantares e serões de Verão.</p>
			 
			<p>Completamente murada e vedada ao exterior, na casa de S. Bento poderá usufruir do melhor da natureza em sossego absoluto, disfrutando das 
			paisagens magníficas da Serra do Gerês e das potencialidades do Rio, que se espraia a escassos metros.</em></p>
			</div>
		</section>

		<section class="barra_reserva">
				<div id="reserva" class="wrapper_reserva">
					<h3>Reserva</h3>
				</div>
		</section>

		<section>
			<form id="form" name="form" method="post" action="index.php?action=1#reserva">
				<label>Nome</label>
			    <input name="nome" id="nome" placeholder="ex.:João Mourinho" required>

			    <label>Email</label>
			    <input name="email" id="email" type="email" placeholder="ex.:nome@dominio.com" required>

			    <label>Telemóvel</label>
			    <input name="telemovel" id="telemovel" type="number" placeholder="ex.:912051395" required>
			            
			    <label>Do dia</label>
			    <input name="data_inicio" id="data_inicio" type="date" placeholder="ex.:2019-10-15" required>

			     <label>Até</label>
			    <input name="data_fim" id="data_fim" type="date" placeholder="ex.:2019-10-15"required>

			    <label>Quanto é 7+2? (Anti-spam)</label>
			    <input type="hidden" name="antispam_calculo" value="7+2">
				<input name="antispam" id="antispam" placeholder="Resultado" required>
					            
			    <input id="submitreserva" name="submitreserva" type="submit" value="Confirmar Reserva">
			    <div id="reserva">

			    	<?php 
				if(isset($_GET['action'])){
					if($_GET['action'] == 1){
						$nome         = $_POST['nome'];
						$email        = $_POST['email'];
						$telemovel    = $_POST['telemovel'];
						$data_inicio  = $_POST['data_inicio'];
						$data_fim     = $_POST['data_fim'];
						
						$antispam     = $_POST['antispam'];
						$antispam_c   = $_POST['antispam_calculo'];

						$antispam_correto = false;
						if (isset($_POST['antispam'])) {
							$operacao = $_POST['antispam_calculo'];
							$numeros  = explode('+', $operacao);
							$conta    = $numeros[0] + $numeros[1];
							if ($conta == $antispam)
								$antispam_correto = true;
						}

	// ---------------------------------------------------------------------
	// MANIPULAÇÃO DA BASE DE DADOS
	// ---------------------------------------------------------------------

	// Passo 1
	// Estabelecer ligação (conexão) com a base de dados
	// ---------------------------------------------------------------------
	$servidorBD   = 'localhost';
  	$utilizadorBD = 'root';
  	$passwordBD   = '';
  	$nomeBD       = 'website';
  	$ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

	// Passo 2
	// Testar a conexão
	// ---------------------------------------------------------------------
	if(mysqli_connect_errno()){
		die('Não foi possível a ligação à base de dados.'
		. mysqli_connect_error() . ':' 
		. mysqli_connect_errno());
	}

	// Passo 3
	// Definir a query SQL
	// ---------------------------------------------------------------------
	

	if ($antispam_correto) {
		// INSERIR
		$query1 = "INSERT INTO reservas (nome,email,telemovel,data_inicio,data_fim) VALUES ('$_POST[nome]','$_POST[email]','$_POST[telemovel]','$_POST[data_inicio]','$_POST[data_fim]')";
		
		// ATUALIZAR
		// $query1 = "UPDATE contactos SET contacto='917654321' WHERE id_contacto = 1";
		
		// CONSULTAR
		// $query1 = "SELECT * FROM contactos";

		// Passo 4
		// Executar a query e guardar resposta numa variável
		$resultado = mysqli_query($ligacao, $query1);

		// Passo 5
		// Verificar o sucesso da execução da query 
		// ---------------------------------------------------------------------
		if(!$resultado) {
			die('Problemas encontrados na execução da query.');
		} else {
			// Passo 6
			// A execução da query teve sucesso
			// Informar utilizador do sucesso da inserção
			// ---------------------------------------------------------------------
			echo "<div class=\"mensagens sucesso\">Registo feito com sucesso! </div>";
			

			// Passo 7
			// Libertar os dados devolvidos pela Base de Dados
			// ---------------------------------------------------------------------
			// mysqli_free_result($resultado);
		}
	}
	else {

		echo "<div class=\"mensagens insucesso\">Incapaz de realizar o registo!</div>";
	}
	// Passo 8
	// Fechar a ligação à Base de Dados
	// ---------------------------------------------------------------------
	mysqli_close($ligacao);
					}
				}


			?>

		</div>
			</form>


		</section>

		<footer id="footer">
		<div class="wrapper footer">
	
	<?php

	$servidorBD   = 'localhost';
	$utilizadorBD = 'root';
	$passwordBD   = '';
	$nomeBD       = 'website';
	$ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);


	if(mysqli_connect_errno()){
		die('Não foi possível a ligação à base de dados.'
		. mysqli_connect_error() . ':' 
		. mysqli_connect_errno());
	}

	
	$query1 = "SELECT id_perfil,nome, telemovel,email FROM perfil";


	$resultado = mysqli_query($ligacao, $query1);


	if(!$resultado) {
		die('Problemas encontrados na execução da query.');
	} else {


		while($per = mysqli_fetch_assoc($resultado)) {
			$nome = utf8_encode($per['nome']);
			$telemovel = $per['telemovel'];
			$email = $per['email'];
		}


		mysqli_free_result($resultado);
	}

	mysqli_close($ligacao);
	?>
			<ul>
				<li class="links">

				<iframe src="https://www.google.com/maps/embed?pb=!1m27!1m12!1m3!1d3163.2439726263833!2d-8.178790782501679!3d41.65954953365347!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m12!1i0!3e6!4m5!1s0xd251e527e3aa805%3A0x527a69477017ab78!2s4850+Cani%C3%A7ada!3m2!1d41.6584417!2d-8.1803417!4m3!3m2!1d41.6619557!2d-8.1797092!5e1!3m2!1spt-PT!2spt!4v1430150823791" 
				width="700" height="400" frameborder="0" style="border:0"></iframe>

				</li>

				<li class="about">
					
					<table id="tableabout">

						<td>
							<tr>
								<p>Nome</p><?php echo   $nome  ?>
							</tr>
							<br>
							<br>
							<tr>
								<p>Telemovel</p> <?php echo $telemovel  ?>
							</tr>
							<br>
							<br>
							<tr>
								<p>E-mail</p> <?php echo $email  ?>
							</tr>
							<br>
							<br>	
								
						</td>
					</table>
					
				</li>
			</ul>
		</div>

		<div class="copyrights wrapper">
			Copyright © 2019. All Rights Reserved RBdesigner.
		</div>
	</footer>
</body>
</html>
