
	<?php

	// Tratamento dos dados recebidos por POST
	
	$nome         = $_POST['nome'];
	$email        = $_POST['email'];
	$telemovel    = $_POST['telemovel'];
	$data_inicio  = $_POST['data_inicio'];
	$data_fim     = $_POST['data_fim'];
	
	$antispam     = $_POST['antispam'];
	$antispam_c   = $_POST['antispam_calculo'];

	$antispam_correto = false;
	if (isset($_POST['antispam'])) {
		$operacao = $_POST['antispam_calculo'];
		$numeros  = explode('+', $operacao);
		$conta    = $numeros[0] + $numeros[1];
		if ($conta == $antispam)
			$antispam_correto = true;
	}

	// ---------------------------------------------------------------------
	// MANIPULAÇÃO DA BASE DE DADOS
	// ---------------------------------------------------------------------

	// Passo 1
	// Estabelecer ligação (conexão) com a base de dados
	// ---------------------------------------------------------------------
	$servidorBD   = 'localhost';
	$utilizadorBD = 'root';
	$passwordBD   = '';
	$nomeBD       = 'website';
	$ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

	// Passo 2
	// Testar a conexão
	// ---------------------------------------------------------------------
	if(mysqli_connect_errno()){
		die('Não foi possível a ligação à base de dados.'
		. mysqli_connect_error() . ':' 
		. mysqli_connect_errno());
	}

	// Passo 3
	// Definir a query SQL
	// ---------------------------------------------------------------------
	

	if ($antispam_correto) {
		// INSERIR
		$query1 = "INSERT INTO reservas (nome,email,telemovel,data_inicio,data_fim) VALUES ('".$nome."','".$email."','".$telemovel."','".$data_inicio."','".$data_fim."')";

		echo "query1";

		// ATUALIZAR
		// $query1 = "UPDATE contactos SET contacto='917654321' WHERE id_contacto = 1";
		
		// CONSULTAR
		// $query1 = "SELECT * FROM contactos";

		// Passo 4
		// Executar a query e guardar resposta numa variável
		$resultado = mysqli_query($ligacao, $query1);

		// Passo 5
		// Verificar o sucesso da execução da query 
		// ---------------------------------------------------------------------
		if(!$resultado) {
			die('Problemas encontrados na execução da query.');
		} else {
			// Passo 6
			// A execução da query teve sucesso
			// Informar utilizador do sucesso da inserção
			// ---------------------------------------------------------------------
			echo 'Registo inserido com sucesso';

			// Passo 7
			// Libertar os dados devolvidos pela Base de Dados
			// ---------------------------------------------------------------------
			// mysqli_free_result($resultado);
		}
	}
	else {

		echo "texto de insucesso a modificar pelo grupo de trab.";
	}
	// Passo 8
	// Fechar a ligação à Base de Dados
	// ---------------------------------------------------------------------
	mysqli_close($ligacao);
	?>
	