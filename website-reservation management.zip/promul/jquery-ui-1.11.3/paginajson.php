
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link href="/jquery-ui.css" rel="stylesheet">
</head>
<body>

<h2 >Curso</h2>

<p id="textocurso"></p>

<script>
var textocurso = '{"designacao":"<b>Designação:</b> Engenharia da Computação Gráfica e Multimédia","duracao":"<b>Duração: </b>3 anos","vagas":"<b>Vagas</b>28","coordenador":"<b>Coordenador: </b>Prof. Doutor Pedro Moreira","informacao":"<b>Informação:</b>O plano de formação contempla uma forte componente interdisciplinar que pretende formar profissionais com sólidos conhecimentos em Computação Gráfica e Multimédia Interativa.","jornadas":"<b>Jornadas:</b>http://jcgm.estg.ipvc.pt/","fontedados":"<b>Fonte Dados:</b>http://www.ipvc.pt/engenharia-computacao-grafica-multimedia-plano-curricular"}'

var obj = JSON.parse(textocurso);

document.getElementById("textocurso").innerHTML =
obj.designacao + "<br>" +
obj.duracao + "<br>" +
obj.vagas + "<br>" +
obj.coordenador + "<br>" +
obj.informacao + "<br>" +
obj.jornadas + "<br>" +
obj.fontedados;
</script>

<h2 class="demoHeaders">Unidades Curriculares</h2>
<div id="accordion">
	<h3>1ºAno</h3>
	<div><p id="ano1"></p>

<script>
var textouc1 = '{"UC1": "Propedêutica da Matemática","UC2": "Álgebra Linear e Geometria Analítica","UC3": "Arquitecturas e Sistemas de Computadores","UC4": "Algoritmos e Estruturas de Dados","UC5": "Design Gráfico","UC6": "Matemática","UC7": "Física Dinâmica","UC8": "Programação I","UC9": "Sistemas Operativos","UC10": "Comportamento Sociedade e Cidadania I"}'

var obje = JSON.parse(textouc1);

document.getElementById("ano1").innerHTML =
obje.UC1 + "<br>" +
obje.UC2 + "<br>" +
obje.UC3 + "<br>" +
obje.UC4 + "<br>" +
obje.UC5 + "<br>" +
obje.UC6 + "<br>" +
obje.UC7 + "<br>" +
obje.UC8 + "<br>" +
obje.UC9 + "<br>" +
obje.UC10 ;
</script></div>
	<h3>2ºano</h3>
	<div><p id="ano2"></p>

<script>
var textouc2 = '{"UC1": "Matemática para Computação Gráfica","UC2": "Ambientes de Programação Gráfica","UC3": "Computação Gráfica","UC4": "Programação II","UC5": "Bases de Dados","UC6": "Projecto 2D","UC7": "Programação 3D","UC8": "Interacção Homem-Máquina","UC9": "Sistemas Operativos","UC10": "Design Multimédia","UC11": "Redes e Sistemas de Comunicação de Dados","UC12": "Projecto 3D"}'

var objec = JSON.parse(textouc2);

document.getElementById("ano2").innerHTML =
objec.UC1 + "<br>" +
objec.UC2 + "<br>" +
objec.UC3 + "<br>" +
objec.UC4 + "<br>" +
objec.UC5 + "<br>" +
objec.UC6 + "<br>" +
objec.UC7 + "<br>" +
objec.UC8 + "<br>" +
objec.UC9 + "<br>" +
objec.UC10 + "<br>" +
objec.UC11 + "<br>" +
objec.UC12 ;
</script></div>
	<h3>3ºano</h3>
	<div><p id="ano3"></p>

<script>
var textouc3 = '{"UC1": "Sistemas de Informação em Rede","UC2": "Modelação 3D","UC3": "Sistemas Multimédia","UC4": "Produção Audiovisual","UC5": "Sistemas de Informação Geográfica","UC6": "Projecto Web","UC7": "Animação 3D","UC8": "Tecnologias Multimédia","UC9": "Pós-Produção Audiovisual","UC10": "Engenharia de Software","UC11": "Projecto Audiovisual","UC12": "Comportamento, Sociedade e Cidadania II"}'

var objec = JSON.parse(textouc3);

document.getElementById("ano3").innerHTML =
objec.UC1 + "<br>" +
objec.UC2 + "<br>" +
objec.UC3 + "<br>" +
objec.UC4 + "<br>" +
objec.UC5 + "<br>" +
objec.UC6 + "<br>" +
objec.UC7 + "<br>" +
objec.UC8 + "<br>" +
objec.UC9 + "<br>" +
objec.UC10 + "<br>" +
objec.UC11 + "<br>" +
objec.UC12 ;
</script></div>
</div>



</body>
</html>
