-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 12, 2015 at 11:07 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `utilizador` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `utilizador`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `perfil`
--

CREATE TABLE IF NOT EXISTS `perfil` (
  `id_perfil` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telemovel` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id_perfil`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perfil`
--

INSERT INTO `perfil` (`id_perfil`, `nome`, `telemovel`, `email`) VALUES
(1, 'Joao  Nunes', '935856998', 'joaonunes@hotmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `preco`
--

CREATE TABLE IF NOT EXISTS `preco` (
  `id_preco` int(11) NOT NULL AUTO_INCREMENT,
  `preco` varchar(15) NOT NULL,
  PRIMARY KEY (`id_preco`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `preco`
--

INSERT INTO `preco` (`id_preco`, `preco`) VALUES
(1, '10');

-- --------------------------------------------------------

--
-- Table structure for table `promocao`
--

CREATE TABLE IF NOT EXISTS `promocao` (
  `id_promocao` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) NOT NULL,
  `desconto` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`id_promocao`),
  KEY `id_promocao` (`id_promocao`),
  KEY `id_promocao_2` (`id_promocao`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `reservas`
--

CREATE TABLE IF NOT EXISTS `reservas` (
  `id_reserva` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telemovel` varchar(15) NOT NULL,
  `data_inicio` varchar(10) NOT NULL,
  `data_fim` varchar(10) NOT NULL,
  `menssagem` varchar(150) NOT NULL,
  `estado` int(11) NOT NULL,
  `preco` int(11) NOT NULL,
  PRIMARY KEY (`id_reserva`),
  KEY `id_reserva` (`id_reserva`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=76 ;

--
-- Dumping data for table `reservas`
--

INSERT INTO `reservas` (`id_reserva`, `nome`, `email`, `telemovel`, `data_inicio`, `data_fim`, `menssagem`, `estado`, `preco`) VALUES
(70, 'Teste1', 'teste1@gmail.com', '965856998', '2015-05-13', '2015-05-17', '', 2, 0),
(71, 'Teste2', 'teste2@gmail.com', '965856998', '2015-05-13', '2015-05-17', '', 1, 0),
(73, 'Teste2', 'teste2@teste.com', '965856998', '2015-05-13', '2015-05-17', '', 0, 0),
(74, 'RÃºben Diogo Amaral Baptista', 'sirubatista@gmail.com', '965856998', '2015-05-13', '2015-05-23', '', 2, 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
