<?php
session_start();
$_SESSION['acesso_valido'] = 0;
if (isset($_POST['utilizador']) && isset($_POST['password'])) {
	// se está definido...
	
	$utilizador = $_POST['utilizador'];
	$password   = $_POST['password'];
	

	// Passo 1
	// Estabelecer ligação (conexão) com a base de dados
	// ---------------------------------------------------------------------
	$servidorBD   = 'localhost';
	$utilizadorBD = 'root';
	$passwordBD   = '';
	$nomeBD       = 'website';
	$ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

	// Passo 2
	// Testar a conexão
	// ---------------------------------------------------------------------
	if(mysqli_connect_errno()){
		die('Não foi possível a ligação à base de dados.'
		. mysqli_connect_error() . ':' 
		. mysqli_connect_errno());
	}

	// Passo 3
	// Definir a query SQL
	// 
	
	// verificar utilizador e palavra-passe na BD
	$query1=	"SELECT * FROM admin WHERE utilizador ='" .$utilizador . "' AND password ='". $password."'";
	
	$resultado = mysqli_query($ligacao, $query1);
	
	if(!$resultado) {
		die('Problemas encontrados na execução da query.');
	} else {
		
	

	if($admin = mysqli_fetch_assoc($resultado)) {
		// entrar nas páginas de acesso restrito
		$_SESSION['acesso_valido'] = 1;
		header('Location: listar_reserva.php');
		
	}
	
	else {
			header('Location: login.php?erro=1');
	}
	
}
}
else {
	header('Location: login.php');
}

?>