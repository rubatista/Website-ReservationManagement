<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>RESERVAS</title>
</head>

<style>
	table#contactos td{
		background-color: #ddddff;
		padding: 6px;
	}
</style>	

<body>	

	<h1>Gestão de reservas</h1>
	<h3>Atualização de reservas (atualização da base de dados)</h3>

	
	<?php

	// Tratamento dos dados recebidos por POST
	$id_reserva  = $_POST['id_reserva'];
	$nome        = $_POST['nome'];
	$email		 = $_POST['email'];
	$telemovel	 = $_POST['telemovel'];
	$data_inicio = $_POST['data_inicio']; 
	$data_fim    = $_POST['data_fim']; 
	$menssagem	 = $_POST['menssagem'];

	// ---------------------------------------------------------------------
	// MANIPULAÇÃO DA BASE DE DADOS
	// ---------------------------------------------------------------------

	// Passo 1
	// Estabelecer ligação (conexão) com a base de dados
	// ---------------------------------------------------------------------
	$servidorBD   = 'localhost';
	$utilizadorBD = 'root';
	$passwordBD   = '';
	$nomeBD       = 'website';
	$ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

	// Passo 2
	// Testar a conexão
	// ---------------------------------------------------------------------
	if(mysqli_connect_errno()){
		die('Não foi possível a ligação à base de dados.'
		. mysqli_connect_error() . ':' 
		. mysqli_connect_errno());
	}

	// Passo 3
	// Definir a query SQL
	// ---------------------------------------------------------------------
	
	// INSERIR
	// $query1 = "INSERT INTO contactos (nome,contacto) VALUES ('".$nome."', '".$contacto."')";

	// ATUALIZAR
	$query1 = "UPDATE reservas SET nome='".$nome."', email='".$email."', telemovel='".$telemovel."', data_inicio='".$data_inicio."', data_fim='".$data_fim."', menssagem='".$menssagem."'  WHERE id_reserva = ".$id_reserva;
	
	// CONSULTAR
	// $query1 = "SELECT * FROM contactos";

	// Passo 4
	// Executar a query e guardar resposta numa variável
	$resultado = mysqli_query($ligacao, $query1);

	// Passo 5
	// Verificar o sucesso da execução da query 
	// ---------------------------------------------------------------------
	if(!$resultado) {
		die('Problemas encontrados na execução da query.');
	} else {
		// Passo 6
		// A execução da query teve sucesso
		// Informar utilizador do sucesso da inserção
		// ---------------------------------------------------------------------
		echo 'Registo atualizado com sucesso';

		// Passo 7
		// Libertar os dados devolvidos pela Base de Dados
		// ---------------------------------------------------------------------
		// mysqli_free_result($resultado);
	}

	// Passo 8
	// Fechar a ligação à Base de Dados
	// ---------------------------------------------------------------------
	mysqli_close($ligacao);
	?>
	
</body>
</html>



