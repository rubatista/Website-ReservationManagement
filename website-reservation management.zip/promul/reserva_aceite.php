<!doctype html>
<?php
session_start();
if ($_SESSION['acesso_valido'] != 1)
  header('Location: login.php');
?>
<html>
<head>
  <meta charset="utf-8">
  <title>Administração</title>
<link rel="icon" type="image/png" href="imagens/cenas-03.png">
  <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>
 
<body>  

  <nav class="navbar navbar-inverse navbar-fixed-top">

      <div class="container-fluid">

        <div class="navbar-header">

          <a class="navbar-brand" href="index.php" target="_blank">Casa S.Bento</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="perfil.php">Perfil</a></li>
            <li><a href="ajuda.php">Ajuda</a></li>
            <li><a href="logout.php">Sair</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid">

      <div class="row">

        <div class="col-sm-3 col-md-2 sidebar">

         <ul class="nav nav-sidebar">

            <li class="active"><a>Reservas<span class="sr-only">(current)</span></a></li>
            <li ><a href="listar_reserva.php">Reservas Pendentes</a></li>
            <li><a href="reserva_aceite.php">Reservas Aceites</a></li>
            <li><a href="reserva_rejeitada.php">Reservas Rejeitadas</a></li>
          </ul>
          <ul class="nav nav-sidebar" >
            <li class="active"><a>Preços</a></li>
            <li><a href="atualizar_preco.php">Atualizar Preço</a></li>
            <li><a >Promoção<h6>*(em construção)*</h6></a></li>
          </ul>
          <!--<ul class="nav nav-sidebar">
            <li class="active"><a>Fotografias</a></li>
            <li><a href="">Inserir Fotografias</a></li>
            <li><a href="">Atualizar Descrição</a></li>
            <li><a href="">Apagar Fotografias</a></li>  
          </ul>-->
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Reservas Aceites</h1>

          <div class="row placeholders">

            
          </div>

         <?php

  // ---------------------------------------------------------------------
  // LISTAGEM DE INFORMAÇÃO DA BASE DE DADOS
  // ---------------------------------------------------------------------

  // Passo 1
  // Estabelecer ligação (conexão) com a base de dados
  // ---------------------------------------------------------------------
  $servidorBD   = 'localhost';
  $utilizadorBD = 'root';
  $passwordBD   = '';
  $nomeBD       = 'website';
  $ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

  // Passo 2
  // Testar a conexão
  // ---------------------------------------------------------------------
  if(mysqli_connect_errno()){
    die('Não foi possível a ligação à base de dados.'
    . mysqli_connect_error() . ':' 
    . mysqli_connect_errno());
  }

  // Passo 3
  // Definir a query SQL
  // ---------------------------------------------------------------------
  
  // INSERIR
  // $query1 = "INSERT INTO contacto (nome,contacto) VALUES ('José Viana', '961234567')";

  // ATUALIZAR
  // $query1 = "UPDATE contacto SET contacto='917654321' WHERE id_contacto = 1";
  
  // CONSULTAR
  $query1 = "SELECT * FROM reservas where estado = 2";

  // Passo 4
  // Executar a query e guardar resposta numa variável
  $resultado = mysqli_query($ligacao, $query1);

  // Passo 5
  // Verificar o sucesso da execução da query 
  // ---------------------------------------------------------------------
  if(!$resultado) {
    die('Problemas encontrados na execução da query.');
  } else {
    // Passo 6x\
    // A execução da query teve sucesso
    // Percorrer cada uma das linhas devolvidas da Base de Dados e mostrar dados
    // ---------------------------------------------------------------------
    
    echo '<div class="table-responsive">';

    echo '<table class="table table-striped">';
      
      echo '<thead>';
      echo '<tr>' ;
      
      echo '<td ><b>' . 'Nome' . '</b></td>';
      echo '<td ><b>' . 'E-mail' . '</b></td>';
      echo '<td ><b>' . 'Telemovel' . '</b></td>';
      echo '<td ><b>' . 'Primeiro Dia' . '</b></td>';
      echo '<td ><b>' . 'Ultimo dia' . '</b></td>';
      echo '<td ><b>' . '' . '</b></td>';
      echo '<tr>';
      echo '</thead>';


    while($reservas = mysqli_fetch_assoc($resultado)) {

      echo '<tbody>';
      echo '<tr>' ;
      
      echo '<td>' . utf8_encode($reservas['nome']) . '</td>';
      echo '<td>' . utf8_encode($reservas['email']) . '</td>';
      echo '<td>' . utf8_encode($reservas['telemovel']) . '</td>';
      echo '<td>' . $reservas['data_inicio'] . '</td>';
      echo '<td>' . $reservas['data_fim'] . '</td>';
      echo '<td><a href="reserva_aceite.php?id_reserva=' . $reservas['id_reserva'] . '&&action=delete"><img src="imagens/xis.png" height="20" width="20"></a></td>';
      echo '<tr>';
      echo '</tbody>';
    }
    echo '</table>';
    if(isset($_GET['action'])){
      if($_GET['action'] == 'delete'){

        if (isset($_GET['id_reserva'])){
    if (trim($_GET['id_reserva']) != '') {
      if (is_numeric($_GET['id_reserva'])) {
        $id_reserva = trim($_GET['id_reserva']);
      }
      else {
        echo "Os parâmetros necessários não estão definidos";
        exit();
      }
    }
    else {
      echo "Os parâmetros necessários não estão definidos";
      exit();
    }
  }
  else {
    echo "Os parâmetros necessários não estão definidos";
    exit();
  }



  // ---------------------------------------------------------------------
  // LISTAGEM DE INFORMAÇÃO DA BASE DE DADOS
  // ---------------------------------------------------------------------

  // Passo 1
  // Estabelecer ligação (conexão) com a base de dados
  // ---------------------------------------------------------------------
  $servidorBD   = 'localhost';
  $utilizadorBD = 'root';
  $passwordBD   = 'usbw';
  $nomeBD       = 'website';
  $ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

  // Passo 2
  // Testar a conexão
  // ---------------------------------------------------------------------
  if(mysqli_connect_errno()){
    die('Não foi possível a ligação à base de dados.'
    . mysqli_connect_error() . ':' 
    . mysqli_connect_errno());
  }

  // Passo 3
  // Definir a query SQL
  // ---------------------------------------------------------------------
  
  // INSERIR
  // $query1 = "INSERT INTO contacto (nome,contacto) VALUES ('José Viana', '961234567')";

  // ATUALIZAR
  // $query1 = "UPDATE contacto SET contacto='917654321' WHERE id_contacto = 1";
  
  // CONSULTAR
  
  $query1 = "DELETE  FROM reservas WHERE id_reserva = " . $id_reserva;

  // Passo 4
  // Executar a query e guardar resposta numa variável
  $resultado = mysqli_query($ligacao, $query1);
  
  // Passo 5
  // Verificar o sucesso da execução da query 
  // ---------------------------------------------------------------------
  if(!$resultado) {
    die('Problemas encontrados na execução da query.');
  } else {
    
  }

  // Passo 8
  // Fechar a ligação à Base de Dados

  // ---------------------------------------------------------------------
  mysqli_close($ligacao);
  
      }
     }
    echo '</div>';



    // Passo 7
    // Libertar os dados devolvidos pela Base de Dados
    // ---------------------------------------------------------------------
    /*mysqli_free_result($resultado);*/
  }

  // Passo 8
  // Fechar a ligação à Base de Dados
  // ---------------------------------------------------------------------
 /* mysqli_close($ligacao);*/
  ?>

    

      
          
        </div>
      </div>
    </div>

  <script src="js/jquery-2.1.3.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
