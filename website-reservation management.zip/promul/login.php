<!doctype html>
<?php
session_start();
?>
<html>
<head>
	<meta charset="utf-8">
	<title>Administração</title>
<link rel="icon" type="image/png" href="imagens/cenas-03.png">
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
	<link href="css/signin.css" rel="stylesheet">

</head>
 
<body>	

	
	<div id="container">

	<form class="form-signin" action="verifica_login.php" method="post">


		<h2 class="form-signin-heading">Faça o login</h2>

        <label for="inputEmail" class="sr-only">Utilizador</label>

        <input type="text" id="utilizador" name="utilizador" class="form-control" placeholder="Insira Utilizador" required autofocus>

        <label for="inputPassword" class="sr-only">Password</label>
        
        <input type="password" id="password" name="password" class="form-control" placeholder="Insira Password" required>
        <div class="checkbox">
          <label>
            <input type="checkbox" value="remember-me"> Lembrar-me
          </label>
        </div>
        <button class="btn btn-lg btn-primary btn-block" value="Entrar" type="submit">Entrar</button>
        <br>
        <?php
			if (isset($_GET['erro'])) {
			if ($_GET['erro'] == 1)
				echo "<div class=\"alert alert-danger\" id=\"alerta\" role=\"alert\">Credenciais de acesso inválidas</div>";
			}
		?>
      </form>


  		

	<script src="js/jquery-2.1.3.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>