<?php   
session_start(); 
session_destroy(); 
header("location:/promul/login.php"); 
exit();
?>