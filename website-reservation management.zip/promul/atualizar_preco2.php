<!doctype html>
<?php
session_start();
if ($_SESSION['acesso_valido'] != 1)
  header('Location: login.php');
?>
<html>
<head>
  <meta charset="utf-8">
  <title>Administração</title>
<link rel="icon" type="image/png" href="imagens/cenas-03.png">
  <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>
 
<body>  

  <nav class="navbar navbar-inverse navbar-fixed-top">

      <div class="container-fluid">

        <div class="navbar-header">

          <a class="navbar-brand" href="index.php" target="_blank">Casa S.Bento</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="perfil.php">Perfil</a></li>
            <li><a href="ajuda.php">Ajuda</a></li>
            <li><a href="logout.php">Sair</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container-fluid">

      <div class="row">

        <div class="col-sm-3 col-md-2 sidebar">

          <ul class="nav nav-sidebar">

            <li class="active"><a>Reservas<span class="sr-only">(current)</span></a></li>
            <li ><a href="listar_reserva.php">Reservas Pendentes</a></li>
            <li><a href="reserva_aceite.php">Reservas Aceites</a></li>
            <li><a href="reserva_rejeitada.php">Reservas Rejeitadas</a></li>
          </ul>
          <ul class="nav nav-sidebar" >
            <li class="active"><a>Preços</a></li>
            <li><a href="atualizar_preco.php">Atualizar Preço</a></li>
            <li><a >Promoção<h6>*(em construção)*</h6></a></li>
          </ul>
          <!--<ul class="nav nav-sidebar">
            <li class="active"><a>Fotografias</a></li>
            <li><a href="">Inserir Fotografias</a></li>
            <li><a href="">Atualizar Descrição</a></li>
            <li><a href="">Apagar Fotografias</a></li>  
          </ul>-->
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">Atualizar Preço</h1>

          <div class="row placeholders"></div>
          
         <?php
  if (isset($_GET['id_preco'])){
    if (trim($_GET['id_preco']) != '') {
      if (is_numeric($_GET['id_preco'])) {
        $id_preco= trim($_GET['id_preco']);
      }
      else {
        echo "Os parâmetros necessários não estão definidos";
        exit();
      }
    }
    else {
      echo "Os parâmetros necessários não estão definidos";
      exit();
    }
  }
  else {
    echo "Os parâmetros necessários não estão definidos";
    exit();
  }



  // ---------------------------------------------------------------------
  // LISTAGEM DE INFORMAÇÃO DA BASE DE DADOS
  // ---------------------------------------------------------------------

  // Passo 1
  // Estabelecer ligação (conexão) com a base de dados
  // ---------------------------------------------------------------------
  $servidorBD   = 'localhost';
  $utilizadorBD = 'root';
  $passwordBD   = '';
  $nomeBD       = 'website';
  $ligacao      = mysqli_connect($servidorBD, $utilizadorBD, $passwordBD, $nomeBD);

  // Passo 2
  // Testar a conexão
  // ---------------------------------------------------------------------
  if(mysqli_connect_errno()){
    die('Não foi possível a ligação à base de dados.'
    . mysqli_connect_error() . ':' 
    . mysqli_connect_errno());
  }

  // Passo 3
  // Definir a query SQL
  // ---------------------------------------------------------------------
  
  // INSERIR
  // $query1 = "INSERT INTO contacto (nome,contacto) VALUES ('José Viana', '961234567')";

  // ATUALIZAR
  // $query1 = "UPDATE contacto SET contacto='917654321' WHERE id_contacto = 1";
  
  // CONSULTAR
  
  $query1 = "SELECT * FROM preco WHERE id_preco = " . $id_preco;

  // Passo 4
  // Executar a query e guardar resposta numa variável
  $resultado = mysqli_query($ligacao, $query1);
  $num_registos_encontrados = $resultado->num_rows;
  // Passo 5
  // Verificar o sucesso da execução da query 
  // ---------------------------------------------------------------------
  if(!$resultado) {
    die('Problemas encontrados na execução da query.');
  } else {
    // Passo 6
    // A execução da query teve sucesso
    // Percorrer cada uma das linhas devolvidas da Base de Dados e mostrar dados
    // ---------------------------------------------------------------------

    while($preco = mysqli_fetch_assoc($resultado)) {
      $id_preco  =  $preco['id_preco'];
      $preco        =  utf8_encode($preco['preco']);
      
      
    }

    // Passo 7
    // Libertar os dados devolvidos pela Base de Dados
    // ---------------------------------------------------------------------
    mysqli_free_result($resultado);
  }

  // Passo 8
  // Fechar a ligação à Base de Dados

  // ---------------------------------------------------------------------
  mysqli_close($ligacao);
  ?>
  
  <?php
  if ($num_registos_encontrados > 0) {
  ?>
  <form name="contacto" method="post" action="atualizar_preco3.php">
    <table id="contactos">
     
      <tr>
        <td>Preço</td>
        <td>
          <input type="text" name="preco" size="50" required value="<?php echo $preco;?>">
        </td>
      </tr>
      
      
      <tr>
        <td colspan="2" align="right">
          <input type="submit" value="Atualizar">
        </td>
      </tr>
    </table>
  </form>
  <?php
  } else {
    echo "Parâmetros incorretamente definidos"; 
  }
  ?>


          
          
        </div>
      </div>
    </div>

  <script src="js/jquery-2.1.3.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>